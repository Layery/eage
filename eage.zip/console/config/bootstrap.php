<?php
////run mode
//foreach (['live','test','develop','local','rehearse'] as $mode)
//{
//	if (file_exists(Yii::getAlias('@api')."/config/{$mode}.lock"))
//	{
//		define('APP_MODE',$mode);
//		break;
//	}
//}
//defined('APP_MODE') or exit('Invalid App Mode');
//define('HOST', APP_MODE=='local' ? 'fykc.cc' : 'fuyoukache.com');
//define('APP_MODE_PATH', Yii::getAlias('@api').'/config/mode');