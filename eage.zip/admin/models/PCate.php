<?php 
namespace admin\models;

use common\models\Cate;

class PCate extends Cate
{
    
}