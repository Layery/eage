<div data-options="region:'north',border:false" style="height:60px;background:#9cd2ff;padding:10px">
    <h2 style="color:#006fb5">管理后台</h2>
</div>