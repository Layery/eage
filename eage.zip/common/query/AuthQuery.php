<?php
/**
 * Created by PhpStorm.
 * User: 未定义
 * Date: 2017/3/26
 * Time: 17:23
 */
namespace common\query;

use common\query\BaseQuery;

class AuthQuery extends BaseQuery
{

}