<div class="col-md-4 column">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">
                Panel title
            </h3>
        </div>
        <div class="panel-body">
            Panel content
        </div>
        <div class="panel-footer">
            Panel footer
        </div>
    </div>
</div>