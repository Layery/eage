<?php
/**
 * Created by PhpStorm.
 * User: 未定义
 * Date: 2017/3/6
 * Time: 0:37
 */

namespace frontend\models;

use Yii;
use yii\db\Query;
use common\models\Cate;
use yii\data\ActiveDataProvider;

class PCate extends Cate
{

}