<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
$this->title = 'Layery';
//$this->js = Html::jsFile('/js/controllers/site-index.js');
?>
<script src="/js/controllers/site-index.js"></script>
